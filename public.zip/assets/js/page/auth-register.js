"use strict";

$(".pwstrength").pwstrength();